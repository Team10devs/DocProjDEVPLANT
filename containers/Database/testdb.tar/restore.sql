--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.3 (Debian 14.3-1.pgdg110+1)
-- Dumped by pg_dump version 16.3 (Debian 16.3-1.pgdg120+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE devplant_team10;
--
-- Name: devplant_team10; Type: DATABASE; Schema: -; Owner: guest
--

CREATE DATABASE devplant_team10 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE devplant_team10 OWNER TO guest;

\connect devplant_team10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: root
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO root;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Companies; Type: TABLE; Schema: public; Owner: guest
--

CREATE TABLE public."Companies" (
    "Id" text NOT NULL,
    "Name" text NOT NULL
);


ALTER TABLE public."Companies" OWNER TO guest;

--
-- Name: PdfModel; Type: TABLE; Schema: public; Owner: guest
--

CREATE TABLE public."PdfModel" (
    "Id" text NOT NULL,
    "Content" bytea NOT NULL,
    "TemplateId" text NOT NULL
);


ALTER TABLE public."PdfModel" OWNER TO guest;

--
-- Name: Templates; Type: TABLE; Schema: public; Owner: guest
--

CREATE TABLE public."Templates" (
    "Id" text NOT NULL,
    "Name" text NOT NULL,
    "DocxFile" bytea NOT NULL,
    "CompanyId" text NOT NULL
);


ALTER TABLE public."Templates" OWNER TO guest;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: guest
--

CREATE TABLE public."Users" (
    "Id" text NOT NULL,
    "UserName" text NOT NULL,
    "Email" text NOT NULL,
    "Address" text NOT NULL,
    "FullName" text NOT NULL,
    "CNP" text NOT NULL,
    "Role" integer NOT NULL,
    "CompanyId" text DEFAULT ''::text,
    "isEmail" boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Users" OWNER TO guest;

--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: guest
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO guest;

--
-- Data for Name: Companies; Type: TABLE DATA; Schema: public; Owner: guest
--

COPY public."Companies" ("Id", "Name") FROM stdin;
\.
COPY public."Companies" ("Id", "Name") FROM '$$PATH$$/3340.dat';

--
-- Data for Name: PdfModel; Type: TABLE DATA; Schema: public; Owner: guest
--

COPY public."PdfModel" ("Id", "Content", "TemplateId") FROM stdin;
\.
COPY public."PdfModel" ("Id", "Content", "TemplateId") FROM '$$PATH$$/3343.dat';

--
-- Data for Name: Templates; Type: TABLE DATA; Schema: public; Owner: guest
--

COPY public."Templates" ("Id", "Name", "DocxFile", "CompanyId") FROM stdin;
\.
COPY public."Templates" ("Id", "Name", "DocxFile", "CompanyId") FROM '$$PATH$$/3342.dat';

--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: guest
--

COPY public."Users" ("Id", "UserName", "Email", "Address", "FullName", "CNP", "Role", "CompanyId", "isEmail") FROM stdin;
\.
COPY public."Users" ("Id", "UserName", "Email", "Address", "FullName", "CNP", "Role", "CompanyId", "isEmail") FROM '$$PATH$$/3341.dat';

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: guest
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/3339.dat';

--
-- Name: Companies PK_Companies; Type: CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."Companies"
    ADD CONSTRAINT "PK_Companies" PRIMARY KEY ("Id");


--
-- Name: PdfModel PK_PdfModel; Type: CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."PdfModel"
    ADD CONSTRAINT "PK_PdfModel" PRIMARY KEY ("Id");


--
-- Name: Templates PK_Templates; Type: CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."Templates"
    ADD CONSTRAINT "PK_Templates" PRIMARY KEY ("Id");


--
-- Name: Users PK_Users; Type: CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "PK_Users" PRIMARY KEY ("Id");


--
-- Name: __EFMigrationsHistory PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: IX_PdfModel_TemplateId; Type: INDEX; Schema: public; Owner: guest
--

CREATE INDEX "IX_PdfModel_TemplateId" ON public."PdfModel" USING btree ("TemplateId");


--
-- Name: IX_Templates_CompanyId; Type: INDEX; Schema: public; Owner: guest
--

CREATE INDEX "IX_Templates_CompanyId" ON public."Templates" USING btree ("CompanyId");


--
-- Name: IX_Users_CompanyId; Type: INDEX; Schema: public; Owner: guest
--

CREATE INDEX "IX_Users_CompanyId" ON public."Users" USING btree ("CompanyId");


--
-- Name: PdfModel FK_PdfModel_Templates_TemplateId; Type: FK CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."PdfModel"
    ADD CONSTRAINT "FK_PdfModel_Templates_TemplateId" FOREIGN KEY ("TemplateId") REFERENCES public."Templates"("Id") ON DELETE CASCADE;


--
-- Name: Templates FK_Templates_Companies_CompanyId; Type: FK CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."Templates"
    ADD CONSTRAINT "FK_Templates_Companies_CompanyId" FOREIGN KEY ("CompanyId") REFERENCES public."Companies"("Id") ON DELETE CASCADE;


--
-- Name: Users FK_Users_Companies_CompanyId; Type: FK CONSTRAINT; Schema: public; Owner: guest
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "FK_Users_Companies_CompanyId" FOREIGN KEY ("CompanyId") REFERENCES public."Companies"("Id");


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: root
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

